package com.aptech.cricstat.fragments;

import android.app.AlertDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.aptech.cricstat.R;
import com.aptech.cricstat.adapter.MyAdapter;
import com.aptech.cricstat.database.MydbHelper;
import com.aptech.cricstat.pojo.Pojo;

import java.util.List;


public class viewplayer extends Fragment{
    public RecyclerView recyclerView;
public  MyAdapter myAdapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_viewplayer, container, false);

                super.onCreateView(inflater, container, savedInstanceState);
        initviews(view);
        return view;

    }

       public void initviews (View view){
        MydbHelper mydbHelper=new MydbHelper(getContext());
           final List<Pojo> list =mydbHelper.getStats();
           RecyclerView recyclerView = view.findViewById(R.id.rv);

               myAdapter = new MyAdapter(list);
               recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
               recyclerView.setAdapter(myAdapter);
               myAdapter.notifyDataSetChanged();
               myAdapter.setOnItemClickListener(new MyAdapter.OnItemClickListener() {
//                   @Override
//                   public void onItemClick(int pos) {
//
//                   }

                   @Override
                   public void onItemClick(int pos, int id) {
                       loadViewPlayerFragment(id);
                   }


               });



    }

    private void loadViewPlayerFragment(int id) {
        FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        display viewPlayerInfo=new display(id);
        fragmentTransaction.replace(R.id.main_fl_container,viewPlayerInfo,viewPlayerInfo.getTag());
        fragmentTransaction.addToBackStack(viewPlayerInfo.getTag());
        fragmentTransaction.commit();
    }


}



