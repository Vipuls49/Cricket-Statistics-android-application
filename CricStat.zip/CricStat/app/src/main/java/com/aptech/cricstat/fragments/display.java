package com.aptech.cricstat.fragments;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.aptech.cricstat.R;
import com.aptech.cricstat.database.MydbHelper;
import com.aptech.cricstat.pojo.Pojo;

public class display extends Fragment {


    public ImageView imageView;
    public TextView textView10;
    public TextView textView11;
    public TextView textView12;
    public TextView textView13;
    public TextView textView14;
    public TextView textView15;
    public TextView textView16;
    public TextView textView17;
    public TextView textView18;
    public TextView textView19;
    public TextView textView20;
    int id;
    public Pojo pojo;
    public MydbHelper mydbHelper;
    public display(int id){
this.id=id;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_display, container, false);

        super.onCreateView(inflater, container, savedInstanceState);
        initviews(view);
        initDatabase();
        populateData();


        return view;

    }

    private void initDatabase() {
        mydbHelper = new MydbHelper(getActivity());
    }

    private void populateData() {

        pojo=mydbHelper.getPlayer(id);

        textView10.setText("Name:  "+pojo.getName());
        textView11.setText("Age:  "+pojo.getAge());
        textView12.setText("Country:  "+pojo.getNationality());
        textView13.setText("Role:  "+pojo.getRole());
        textView14.setText("Debut:  "+pojo.getDate());
        textView15.setText("Total Runs:  "+pojo.getRuns());
        textView16.setText("Wickets:  "+pojo.getWickets());
        textView17.setText("Batting order:  "+pojo.getBatting());
        textView18.setText("Bowling Style:  "+pojo.getBowling());
        textView19.setText("High Score:  "+pojo.getHigh_score());
        textView20.setText("Best Bowling:  "+pojo.getBest_bowling());
    }

    private void initviews(View view) {

        imageView=(ImageView)view.findViewById(R.id.back);
        imageView.setAlpha(27);

        textView10=(TextView)view.findViewById(R.id.name);
        textView11=(TextView)view.findViewById(R.id.age);
        textView12=(TextView)view.findViewById(R.id.country);
        textView13=(TextView)view.findViewById(R.id.role);
        textView14=(TextView)view.findViewById(R.id.debut);
        textView15=(TextView)view.findViewById(R.id.runs);
        textView16=(TextView)view.findViewById(R.id.wickets);
        textView17=(TextView)view.findViewById(R.id.bat);
        textView18=(TextView)view.findViewById(R.id.bowl);
        textView19=(TextView)view.findViewById(R.id.hs);
        textView20=(TextView)view.findViewById(R.id.bb);

    }
}
