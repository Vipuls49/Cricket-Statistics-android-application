package com.aptech.cricstat.fragments;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import com.aptech.cricstat.pojo.Pojo;
import com.aptech.cricstat.database.MydbHelper;
import com.aptech.cricstat.R;

import android.service.autofill.Validator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static com.aptech.cricstat.R.layout.support_simple_spinner_dropdown_item;


public class addplayer extends Fragment implements View.OnClickListener, AdapterView.OnItemSelectedListener , DatePickerDialog.OnDateSetListener {
    private TextView textView1;
    private ImageView imageView1;
    private EditText editText1;
    private EditText editText2;
    private EditText editText3;
    private EditText editText4;
    private EditText editText5;
    private EditText editText6;
    private EditText editText7;
    private Spinner spinner1;
    private Spinner spinner2;
    private Spinner spinner3;
    private Spinner spinner4;
    private Button button1;
    private Button button2;
    private Button button3;
    private MydbHelper dbHelper;
    private Calendar calendar;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_addplayer, container, false);
        initviews(view);
        initspinner();
        initDatabase();
        initlisteners();



        super.onCreateView(inflater, container, savedInstanceState);
        return view;


    }

    private void initspinner() {
        List<String> ball = new ArrayList<String>();
        ball.add("---SELECT---");
        ball.add("Right arm fast");
        ball.add("Left arm fast");
        ball.add("Medium Fast");
        ball.add("Off break");
        ball.add("Leg Spin");
        ball.add("Chinaman");
        ball.add("Slow Left arm");
        ArrayAdapter arrayAdapter1 = new ArrayAdapter<String>(getActivity(), support_simple_spinner_dropdown_item, ball);
        arrayAdapter1.setDropDownViewResource(support_simple_spinner_dropdown_item);
        spinner1.setAdapter(arrayAdapter1);
        spinner1.setSelection(1);

        List<String> bat = new ArrayList<String>();
        bat.add("---SELECT---");
        bat.add("Opening batsman");
        bat.add("Middle order");
        bat.add("Tailender");

        ArrayAdapter arrayAdapter2 = new ArrayAdapter<String>(getActivity(), support_simple_spinner_dropdown_item, bat);
        arrayAdapter2.setDropDownViewResource(support_simple_spinner_dropdown_item);
        spinner2.setAdapter(arrayAdapter2);
        spinner2.setSelection(1);


        List<String> role = new ArrayList<String>();
        role.add("---SELECT---");
        role.add("Batsman");
        role.add("Bowler");
        role.add("All-Rounder");

        ArrayAdapter arrayAdapter4 = new ArrayAdapter<String>(getActivity(), support_simple_spinner_dropdown_item,role);
        arrayAdapter4.setDropDownViewResource(support_simple_spinner_dropdown_item);
        spinner4.setAdapter(arrayAdapter4);
        spinner4.setSelection(1);



        List<String> ctry = new ArrayList<String>();
        ctry.add("---SELECT---");
        ctry.add("India");
        ctry.add("Australia");
        ctry.add("England");
        ctry.add("New Zealand");
        ctry.add("South Africa");
        ctry.add("Sri lanka");
        ctry.add("Bangladesh");


        ArrayAdapter arrayAdapter3 = new ArrayAdapter<String>(getActivity(), support_simple_spinner_dropdown_item, ctry);
        arrayAdapter3.setDropDownViewResource(support_simple_spinner_dropdown_item);
        spinner3.setAdapter(arrayAdapter3);
        spinner3.setSelection(1);
    }


    private void initlisteners() {

        editText7.setOnClickListener(this);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        spinner1.setOnItemSelectedListener(this);
        spinner2.setOnItemSelectedListener(this);
        spinner3.setOnItemSelectedListener(this);
        spinner4.setOnItemSelectedListener(this);

    }

    private void initDatabase() {

        dbHelper = new MydbHelper(getActivity());
    }

    private void initviews(View view) {
        calendar = Calendar.getInstance();
        textView1 = (TextView) view.findViewById(R.id.tv_title);
        editText7 = (EditText) view.findViewById(R.id.tvDob);
        imageView1 = (ImageView) view.findViewById(R.id.iv_back);
        imageView1.setAlpha(27);
        editText1 = (EditText) view.findViewById(R.id.et_age);
        editText2 = (EditText) view.findViewById(R.id.et_bowl);
        editText3 = (EditText) view.findViewById(R.id.et_name);
        editText4 = (EditText) view.findViewById(R.id.et_runs);
        editText5 = (EditText) view.findViewById(R.id.et_score);
        editText6 = (EditText) view.findViewById(R.id.et_wickets);
        spinner1 = (Spinner) view.findViewById(R.id.sp_ball);
        spinner2 = (Spinner) view.findViewById(R.id.sp_bat);
        spinner3 = (Spinner) view.findViewById(R.id.sp_country);
        spinner4=(Spinner)view.findViewById(R.id.sp_role);
        button1 = (Button) view.findViewById(R.id.bt_add);
        button2 = (Button) view.findViewById(R.id.bt_update);
        button3 = (Button) view.findViewById(R.id.bt_delete);


    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.tvDob:

                showDatePickerDialog();
                //dbHelper.addStats(getValues(spinner1.getSelectedItemPosition(), spinner2.getSelectedItemPosition(), spinner3.getSelectedItemPosition(),spinner4.getSelectedItemPosition()));
                break;

            case R.id.bt_add:
                    if(valname()&valage()&valwic()&valbb()&valdate()&valruns()) {
                        if (valhs()) {
                            dbHelper.addStats(getValues(spinner1.getSelectedItemPosition(), spinner2.getSelectedItemPosition(), spinner3.getSelectedItemPosition(), spinner4.getSelectedItemPosition()));
                            Toast.makeText(getContext(), "Information Added Suuccessfully", Toast.LENGTH_SHORT).show();
                        }
                    }
                    break;
            case R.id.bt_update:
                dbHelper.updateStats(getValues(spinner1.getSelectedItemPosition(), spinner2.getSelectedItemPosition(), spinner3.getSelectedItemPosition(),spinner4.getSelectedItemPosition()));
                Toast.makeText(getContext(), "Information Updated Suuccessfully", Toast.LENGTH_SHORT).show();
                break;
            case R.id.bt_delete:
                dbHelper.deleteStats(getValues(spinner1.getSelectedItemPosition(), spinner2.getSelectedItemPosition(), spinner3.getSelectedItemPosition(),spinner4.getSelectedItemPosition()));
                Toast.makeText(getContext(), "Information Deleted Suuccessfully", Toast.LENGTH_SHORT).show();
                break;

        }


    }
    private boolean valname()
    {
        if(editText3.getText().toString().isEmpty()){
            editText3.setError("Fields cannot be empty");
            editText3.requestFocus();

            return false;
        }
        else if(!editText3.getText().toString().matches("[a-zA-Z]+"))
        {
            editText3.setError("Only Alphabets are allowed");
            editText3.requestFocus();

            return false;
        }
        else{
            editText3.setError(null);
            return true;
        }
    }
    private boolean valage(){
        int age=Integer.parseInt(editText1.getText().toString());

        if(editText1.getText().toString().isEmpty()){
            editText1.setError("Fields cannot be empty");
            editText1.requestFocus();

            return false;
        }
        else if(age<=12 | age>=60)
        {
            editText1.setError("Age must between 12 to 60");
            editText1.requestFocus();

            return false;

        }
        else {
            editText1.setError(null);
            return true;
        }
    }
    private boolean valdate() {
        if (editText7.getText().toString().trim().equals("DD-MM-YYYY"))
        {
            editText7.setError("Fields cannot be empty.");
            editText7.requestFocus();
            return false;
        }
        else
        {
            editText7.setError(null);
            return true;
        }
    }

    private boolean valruns() {

        if (editText4.getText().toString().trim().isEmpty())
        {
            editText4.setError("Fields cannot be empty.");
            editText4.requestFocus();
            return false;
        }
        else
        {
            editText4.setError(null);
            return true;
        }
    }
    private boolean valbb() {

        if (editText2.getText().toString().trim().isEmpty())
        {
            editText2.setError("Fields cannot be empty.");
            editText2.requestFocus();
            return false;
        }
        else
        {
            editText2.setError(null);
            return true;
        }
    }
    private boolean valwic() {

        if (editText6.getText().toString().trim().isEmpty())
        {
            editText6.setError("Fields cannot be empty.");
            editText6.requestFocus();
            return false;
        }
        else
        {
            editText6.setError(null);
            return true;
        }
    }

    private boolean valhs() {
int hs=Integer.parseInt(editText5.getText().toString());
int run=Integer.parseInt(editText4.getText().toString());
        if (editText5.getText().toString().trim().isEmpty())
        {
            editText5.setError("Fields cannot be empty.");
            editText5.requestFocus();
            return false;
        }
        else if(hs>run){
            editText5.setError("High score not greater than total runs.");
            editText5.requestFocus();
            return false;
        }
        else
        {
            editText5.setError(null);
            return true;
        }
    }

    private Pojo getValues(int p1, int p2, int p3,int p4) {
        Pojo pojo = new Pojo();

        pojo.setName(editText3.getText().toString().trim());
        pojo.setAge(editText1.getText().toString().trim());
        pojo.setNationality(spinner3.getItemAtPosition(p3).toString().trim());
        pojo.setRuns(editText4.getText().toString().trim());
        pojo.setWickets(editText6.getText().toString().trim());
        pojo.setHigh_score(editText5.getText().toString().trim());
        pojo.setBest_bowling(editText2.getText().toString().trim());
        pojo.setBatting(spinner2.getItemAtPosition(p2).toString().trim());
        pojo.setBowling(spinner1.getItemAtPosition(p1).toString().trim());
        pojo.setRole(spinner4.getItemAtPosition(p4).toString().trim());
        pojo.setDate(editText7.getText().toString().trim());


        return pojo;
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        switch (view.getId()) {
            case R.id.sp_ball:
                String item1 = spinner1.getItemAtPosition(i).toString();
                // pos1=i;
                Toast.makeText(getContext(), "selected item is" + item1, Toast.LENGTH_SHORT).show();
                break;
            case R.id.sp_bat:
                String item2 = spinner2.getItemAtPosition(i).toString();
                // pos2=i;
                Toast.makeText(getContext(), "selected item is" + item2, Toast.LENGTH_SHORT).show();
                break;
            case R.id.sp_country:
                String item3 = spinner3.getItemAtPosition(i).toString();
                // pos3=i;
                Toast.makeText(getContext(), "selected item is" + item3, Toast.LENGTH_SHORT).show();
                break;
            case R.id.sp_role:
                String item4 = spinner4.getItemAtPosition(i).toString();
                // pos3=i;
                Toast.makeText(getContext(), "selected item is" + item4, Toast.LENGTH_SHORT).show();
                break;

        }


    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        calendar.set(i, i1, i2);

        String date;
        String month;

        if (i2 < 10) {
            date = "0" + i2;
        } else {
            date = String.valueOf(i2);
        }

        if (i1 < 9) {
            month = "0" + (i1 + 1);
        } else {
            month = String.valueOf(i1 + 1);
        }

        editText7.setText(date + "-" + month + "-" + i);
    }

    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), this, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.getDatePicker().setMaxDate(Calendar.getInstance().getTimeInMillis());
        datePickerDialog.show();
    }
}
