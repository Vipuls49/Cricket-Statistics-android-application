package com.aptech.cricstat.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.aptech.cricstat.pojo.Pojo;

import java.util.ArrayList;
import java.util.List;

public class MydbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "CricketStats16";
    private static final int VERSION = 5;
    private static final String TABLE_NAME = "Statistics";
    private static final String ID = "id";
    private static final String NAME = "name";
    private static final String AGE = "age";
    private static final String NATIONALITY = "nationality";
    private static final String RUNS = "runs";
    private static final String WICKETS = "wickets";
    private static final String HIGH_SCORE = "high_score";
    private static final String BEST_BOWLING = "best_bowling";
    private static final String BATTING = "batting";
    private static final String BOWLING = "bowling";
    private static final String ROLE = "role";
    private static final String DOD = "DateOfDebut";



    public MydbHelper(@Nullable Context context) {
        super(context, DB_NAME,null,VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_TABLE = "CREATE TABLE "
                + TABLE_NAME + " ("
                + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME + " VARCHAR(200), "
                + AGE + " VARCHAR(200), "
                + NATIONALITY + " VARCHAR(200),"
                + RUNS + " VARCHAR(200), "
                + WICKETS + " VARCHAR(200), "
                + HIGH_SCORE + " VARCHAR(200), "
                + BEST_BOWLING + " VARCHAR(200), "
                + BATTING + " VARCHAR(200), "
                + BOWLING+ " VARCHAR(200),"
                +ROLE+" VARCHAR(100),"
                +DOD+" DATE(200)"
                +")";
        sqLiteDatabase.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    public long addStats(Pojo pojo){
        long Id;
        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(NAME, pojo.getName());
        contentValues.put(AGE, pojo.getAge());
        contentValues.put(NATIONALITY, pojo.getNationality());
        contentValues.put(RUNS, pojo.getRuns());
        contentValues.put(WICKETS, pojo.getWickets());
        contentValues.put(HIGH_SCORE, pojo.getHigh_score());
        contentValues.put(BEST_BOWLING, pojo.getBest_bowling());
        contentValues.put(BATTING, pojo.getBatting());
        contentValues.put(BOWLING, pojo.getBowling());
        contentValues.put(ROLE, pojo.getRole());
        contentValues.put(DOD, pojo.getDate());



        Id = db.insert(TABLE_NAME, null, contentValues);
        db.close();

        return Id;
    }

    public int updateStats(Pojo pojo){
        int numOfRows;
        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(AGE, pojo.getAge());
        contentValues.put(RUNS, pojo.getRuns());
        contentValues.put(WICKETS, pojo.getWickets());
        contentValues.put(HIGH_SCORE, pojo.getHigh_score());
        contentValues.put(BEST_BOWLING, pojo.getBest_bowling());
        contentValues.put(NATIONALITY,pojo.getNationality());


        numOfRows = db.update(TABLE_NAME, contentValues, NAME + " = ?", new String[]{pojo.getName()});
        db.close();

        return numOfRows;
    }

    public void deleteStats(Pojo pojo){
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_NAME, NAME + " = ?", new String[]{pojo.getName()});
        db.close();
    }

    public List<Pojo> getStats(){
        List<Pojo> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, null, null, null, null, null, null);

        if(cursor!= null && cursor.moveToFirst()){
            do{
                Pojo pojo = new Pojo();

                pojo.setId(cursor.getInt(cursor.getColumnIndex(ID)));
                pojo.setName(cursor.getString(cursor.getColumnIndex(NAME)));
                pojo.setAge(cursor.getString(cursor.getColumnIndex(AGE)));
                pojo.setNationality(cursor.getString(cursor.getColumnIndex(NATIONALITY)));
                pojo.setRuns(cursor.getString(cursor.getColumnIndex(RUNS)));
                pojo.setWickets(cursor.getString(cursor.getColumnIndex(WICKETS)));
                pojo.setHigh_score(cursor.getString(cursor.getColumnIndex(HIGH_SCORE)));
                pojo.setBest_bowling(cursor.getString(cursor.getColumnIndex(BEST_BOWLING)));
                pojo.setBatting(cursor.getString(cursor.getColumnIndex(BATTING)));
                pojo.setBowling(cursor.getString(cursor.getColumnIndex(BOWLING)));
                pojo.setRole(cursor.getString(cursor.getColumnIndex(ROLE)));
                pojo.setDate(cursor.getString(cursor.getColumnIndex(DOD)));


                list.add(pojo);
            }while (cursor.moveToNext());
        }

        return list;
    }

    //    get all data corresponding to id
    public Pojo getPlayer(int id) {
        List<Pojo> list = new ArrayList<>();
        Pojo pojo = new Pojo();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from "+TABLE_NAME+ " where "+ID+"='"+id+"'",null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
//                Pojo pojo = new Pojo();

                pojo.setId(cursor.getInt(cursor.getColumnIndex(ID)));
                pojo.setName(cursor.getString(cursor.getColumnIndex(NAME)));
                pojo.setAge(cursor.getString(cursor.getColumnIndex(AGE)));
                pojo.setNationality(cursor.getString(cursor.getColumnIndex(NATIONALITY)));
                pojo.setRuns(cursor.getString(cursor.getColumnIndex(RUNS)));
                pojo.setWickets(cursor.getString(cursor.getColumnIndex(WICKETS)));
                pojo.setHigh_score(cursor.getString(cursor.getColumnIndex(HIGH_SCORE)));
                pojo.setBest_bowling(cursor.getString(cursor.getColumnIndex(BEST_BOWLING)));
                pojo.setBatting(cursor.getString(cursor.getColumnIndex(BATTING)));
                pojo.setBowling(cursor.getString(cursor.getColumnIndex(BOWLING)));
                pojo.setRole(cursor.getString(cursor.getColumnIndex(ROLE)));
                pojo.setDate(cursor.getString(cursor.getColumnIndex(DOD)));
            list.add(pojo);
            } while (cursor.moveToNext());
        }
        return pojo;
    }
}
