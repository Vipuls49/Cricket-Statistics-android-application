package com.aptech.cricstat.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.aptech.cricstat.R;
import com.aptech.cricstat.fragments.homepage;

public class MainActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       
        loadFragment();
    }

    private void loadFragment() {
        homepage fragment=new homepage();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        getSupportFragmentManager().beginTransaction();
        for (int i = 0; i < fragmentManager.getBackStackEntryCount(); ++i) {
            fragmentManager.popBackStack();
        }
        fragmentTransaction.replace(R.id.main_fl_container,fragment, fragment.getTag());
        fragmentTransaction.commit();

    }

    @Override
    public void onBackPressed(){
        super.onBackPressed();

        getSupportFragmentManager().popBackStack();
    }






    }




