package com.aptech.cricstat.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.aptech.cricstat.R;

public class SplashScreen extends AppCompatActivity {
    public ImageView imageView2;
    public ImageView imageView3;
    public TextView textView1;
    public TextView textView2;
    public Animation animation;
    public ObjectAnimator fadeInAnimation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        final ImageView imageView2=(ImageView)findViewById(R.id.imageView2);
        final ImageView imageView3=(ImageView)findViewById(R.id.imageView3);

        textView1=(TextView)findViewById(R.id.textView2);
        textView2=(TextView)findViewById(R.id.textView3);
        imageView2.setAlpha(27);

        final ObjectAnimator fadeInAnimation = ObjectAnimator.ofFloat(textView2, View.ALPHA, 0.2f, 1.0f );
        fadeInAnimation.setDuration(2000);
        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fadeInAnimation.start();

            }
        });
        animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.bounce);
    imageView3.startAnimation(animation);
    animation.setAnimationListener(new Animation.AnimationListener() {
        @Override
        public void onAnimationStart(Animation animation) {
            imageView3.startAnimation(animation);
        }

        @Override
        public void onAnimationEnd(Animation animation) {
            imageView3.startAnimation(animation);

        }

        @Override
        public void onAnimationRepeat(Animation animation) {
            imageView3.startAnimation(animation);

        }
    });



        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(SplashScreen.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        },3000);

    }
}
