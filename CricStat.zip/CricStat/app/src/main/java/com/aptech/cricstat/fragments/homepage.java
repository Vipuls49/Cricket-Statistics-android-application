package com.aptech.cricstat.fragments;

import android.animation.ValueAnimator;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.aptech.cricstat.R;


public class homepage extends Fragment implements View.OnClickListener {
    public ImageView imageView1;
    public ImageView imageView2;
    public ImageView imageView5;
    public Button button1;
    public Button button2;
    public TextView textView1;
    public TextView textView2;
    public TextView first;
    public TextView second;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_homepage, container, false);
        initViews(view);
        initListeners();
        super.onCreateView(inflater, container, savedInstanceState);
    return view;

    }

    private void initListeners() {
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
    }

    private void initViews(View view) {
        imageView1 = (ImageView) view.findViewById(R.id.imageView);
       imageView2 = (ImageView) view.findViewById(R.id.imageView4);
      imageView5 = (ImageView) view.findViewById(R.id.imageView5);
       button1 = (Button) view.findViewById(R.id.button);
        button2 = (Button) view.findViewById(R.id.button2);
        textView1 = (TextView) view.findViewById(R.id.textView);
        textView2=(TextView)view.findViewById(R.id.textView4);

        textView2.setMovementMethod(LinkMovementMethod.getInstance());
        imageView5.setAlpha(27);
        first = (TextView)view.findViewById(R.id.first);
         second = (TextView)view.findViewById(R.id.second);
        first.setMovementMethod(LinkMovementMethod.getInstance());
        second.setMovementMethod(LinkMovementMethod.getInstance());
        final ValueAnimator animator = ValueAnimator.ofFloat(0.0f, 1.0f);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.setDuration(9000L);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                final float progress = (float) animation.getAnimatedValue();
                final float width = first.getWidth();
                final float translationX = width * progress;
                first.setTranslationX(translationX);
                second.setTranslationX(translationX - width);
            }
        });
        animator.start();
    }

    private void swapFragment1() {
        addplayer fragment1 = new addplayer();
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.main_fl_container,fragment1);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    private void swapFragment2() {
        viewplayer fragment2 = new viewplayer();
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.main_fl_container, fragment2);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button2:
                swapFragment1();
                break;
            case R.id.button:
                swapFragment2();
                break;


        }
    }


}
