package com.aptech.cricstat.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aptech.cricstat.fragments.addplayer;
import com.aptech.cricstat.fragments.display;
import com.aptech.cricstat.pojo.Pojo;
import com.aptech.cricstat.R;

import java.util.List;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    private List<Pojo> mlistdata;
    private OnItemClickListener mListener;
    public interface OnItemClickListener{
       // void onItemClick(int pos);

        void onItemClick(int pos, int id);
    }
    public void setOnItemClickListener(OnItemClickListener listener)
    {
        mListener=listener;
    }

    public MyAdapter(List<Pojo> listdata){
        mlistdata = listdata;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View listitem = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout, parent, false);

        return new ViewHolder(listitem,mListener);
    }



    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Pojo pojo = mlistdata.get(position);
        holder.textView2.setText(pojo.getName());
        holder.textView3.setText(pojo.getNationality().toString());
        holder.textView4.setText(pojo.getRole());
        holder.textView6.setText(pojo.getAge().toString());
        holder.textView8.setText(pojo.getDate().toString());
        holder.relativeLayout.setTag(pojo.getId());


    }

    @Override
    public int getItemCount() {
        return mlistdata.size();
    }



    class ViewHolder extends RecyclerView.ViewHolder {

    //public ImageView imageView;
   // public TextView textView1;
    public TextView textView2;
    public TextView textView3;
    public TextView textView4;
    public TextView textView5;
    public TextView textView6;
    public TextView textView7;
    public TextView textView8;
    public ImageView imageView;
    public RelativeLayout relativeLayout;

    public ViewHolder(final View itemView, final OnItemClickListener listener) {
        super(itemView);
        this.imageView = (ImageView) itemView.findViewById(R.id.icon1);
        this.textView8=(TextView)itemView.findViewById(R.id.rvdod);
        this.textView5=(TextView)itemView.findViewById(R.id.age);
        this.textView6=(TextView)itemView.findViewById(R.id.rvage);
        this.textView7=(TextView)itemView.findViewById(R.id.dod);

        // this.textView1 = (TextView) itemView.findViewById(R.id.rvid);
        this.textView4=(TextView)itemView.findViewById(R.id.rvrole);
        this.textView2 = (TextView) itemView.findViewById(R.id.rvname);
        this.textView3=(TextView)itemView.findViewById(R.id.rvcountry);

        relativeLayout = (RelativeLayout) itemView.findViewById(R.id.relativeLayout);


        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null){
                    int position=getAdapterPosition();
                    if (position!=RecyclerView.NO_POSITION)
                    {
                        listener.onItemClick(position,Integer.parseInt(relativeLayout.getTag().toString()));
                    }
                }
            }
        });

    }

}

}


