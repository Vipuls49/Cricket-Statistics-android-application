package com.aptech.cricstat.pojo;



public class Pojo {


    private String date;


    private String role;
    private int id;
    private String name;
    private String age;
    private String runs;
    private String wickets;
    private String nationality;
    private String high_score;
    private String best_bowling;
    private String batting;
    private String bowling;
    private int imgId;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Integer getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



    public void setAge(String age) {
        this.age = age;
    }

    public void setRuns(String runs) {
        this.runs = runs;
    }

    public void setWickets(String wickets) {
        this.wickets = wickets;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public void setHigh_score(String high_score) {
        this.high_score = high_score;
    }

    public void setBest_bowling(String best_bowling) {
        this.best_bowling = best_bowling;
    }

    public void setBatting(String batting) {
        this.batting = batting;
    }

    public void setBowling(String bowling) {
        this.bowling = bowling;
    }



    public String getAge() {
        return age;
    }

    public String getRuns() {
        return runs;
    }

    public String getWickets() {
        return wickets;
    }

    public String getNationality() {
        return nationality;
    }

    public String getHigh_score() {
        return high_score;
    }

    public String getBest_bowling() {
        return best_bowling;
    }

    public String getBatting() {
        return batting;
    }

    public String getBowling() {
        return bowling;
    }


//        public Pojo(String description, int imgId) {
//            this.description = description;
//            this.imgId = imgId;
//        }
        public String getName()
        {
            return name;
        }
        public void setName(String description) {
            this.name = description;
        }
        public int getImgId() {
            return imgId;
        }
        public void setImgId(int imgId) {
            this.imgId = imgId;
        }

}
