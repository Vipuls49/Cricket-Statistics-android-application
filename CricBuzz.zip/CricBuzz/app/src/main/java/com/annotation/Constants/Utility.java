package com.annotation.Constants;

import java.util.ArrayList;
import java.util.List;

public class Utility {
    public static String MODEADD="Add";
    public static String MODEEDIT="Edit";

//    Lists for Spinners
    public static List<String> listCountry=new ArrayList<String>(){{
        add("India");
        add("Pakistan");
        add("England");
        add("Shri Lanka");
        add("Bangladesh");
        add("West Indies");
        add("Australia");
        add("South Africa");
    }};
    public static List<String> listRole=new ArrayList<String>(){{
        add("Batsman");
        add("Bowler");
        add("All Rounder");
    }};
    public static List<String> listBattingStyle=new ArrayList<String>(){{
        add("Right Handed Batsman");
        add("Left Handed Batsman");
    }};
    public static List<String> listBowlingStyle=new ArrayList<String>(){{
        add("None");
        add("Right Hand Fast");
        add("Right Hand Medium");
        add("Right Hand Slow");
        add("Left Hand Fast");
        add("Left Hand Medium");
        add("Left Hand Slow");
        add("Right Hand Leg Spin");
        add("Left Hand Leg Spin");
        add("Right Hand Off Spin");
        add("Left Hand Off Spin");
    }};



//    public static void initList(){
//        listCountry.add("India");
//        listCountry.add("Pakistan");
//        listCountry.add("England");
//        listCountry.add("Shri Lanka");
//        listCountry.add("Bangladesh");
//        listCountry.add("West Indies");
//        listCountry.add("Australia");
//        listCountry.add("South Africa");
//
//        listRole.add("Batsman");
//        listRole.add("Bowler");
//        listRole.add("All Rounder");
//
//        listBattingStyle.add("Right Handed Batsman");
//        listBattingStyle.add("Left Handed Batsman");
//
//        listBowlingStyle.add("None");
//        listBowlingStyle.add("Right Hand Fast");
//        listBowlingStyle.add("Right Hand Medium");
//        listBowlingStyle.add("Right Hand Slow");
//        listBowlingStyle.add("Left Hand Fast");
//        listBowlingStyle.add("Left Hand Medium");
//        listBowlingStyle.add("Left Hand Slow");
//        listBowlingStyle.add("Right Hand Leg Spin");
//        listBowlingStyle.add("Left Hand Leg Spin");
//        listBowlingStyle.add("Right Hand Off Spin");
//        listBowlingStyle.add("Left Hand Off Spin");
//    }


    //    database constants
    public static String DATABASE_NAME="cricbuzz.db";

    public static String TABLE_NAME="player";

    public static String PLAYER_TABLE_ID="p_id";
    public static String PLAYER_TABLE_FNAME="p_fname";
    public static String PLAYER_TABLE_LNAME="p_lname";
    public static String PLAYER_TABLE_DOD="p_dod";
    public static String PLAYER_TABLE_AGE="p_age";
    public static String PLAYER_TABLE_COUNTRY="p_country";
    public static String PLAYER_TABLE_GENDER="p_gender";
    public static String PLAYER_TABLE_ROLE="p_role";
    public static String PLAYER_TABLE_BAT_STYLE="p_bat_style";
    public static String PLAYER_TABLE_BOWL_STYLE="p_bowl_style";
    public static String PLAYER_TABLE_TOTAL_RUN="p_total_run";
    public static String PLAYER_TABLE_HALF_CENTURY="p_half_century";
    public static String PLAYER_TABLE_CENTURY="p_century";
    public static String PLAYER_TABLE_NICKNAME="p_nickname";


}
