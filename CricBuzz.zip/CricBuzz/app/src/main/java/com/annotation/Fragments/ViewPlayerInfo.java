package com.annotation.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.annotation.Database.DatabaseHelper;
import com.annotation.Pojo.PlayerPojo;
import com.annotation.cricbuzz.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class ViewPlayerInfo extends Fragment {
    private DatabaseHelper databaseHelper;
    private PlayerPojo playerPojo;

    private TextView tv_p_id;
    private TextView tv_p_name;
    private TextView tv_p_dod;
    private TextView tv_p_age;
    private TextView tv_p_country;
    private TextView tv_p_gender;
    private TextView tv_p_role;
    private TextView tv_p_bat_style;
    private TextView tv_p_bowl_style;
    private TextView tv_p_total_runs;
    private TextView tv_p_half_century;
    private TextView tv_p_century;
    private TextView tv_p_nickname;

    private int id;



    public ViewPlayerInfo(int id) {
        // Required empty public constructor
        this.id=id;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_view_player_info, container, false);
        initViews(view);
        initDatabase();
        populateData();
        return view;
    }


    private void initDatabase() {
        databaseHelper=new DatabaseHelper(getActivity());
    }

    private void populateData() {
        playerPojo=databaseHelper.getPlayer(id);

        tv_p_id.setText(Integer.toString(playerPojo.getP_id()));
        tv_p_name.setText(playerPojo.getP_fname()+" "+playerPojo.getP_lname());
        tv_p_dod.setText(playerPojo.getP_dod());
        tv_p_age.setText(Integer.toString(playerPojo.getP_age()));
        tv_p_country.setText(playerPojo.getP_country());
        tv_p_gender.setText(playerPojo.getP_gender());
        tv_p_role.setText(playerPojo.getP_role());
        tv_p_bat_style.setText(playerPojo.getP_bat_style());
        tv_p_bowl_style.setText(playerPojo.getP_bowl_style());
        tv_p_total_runs.setText(playerPojo.getP_total_run());
        tv_p_half_century.setText(playerPojo.getP_half_century());
        tv_p_century.setText(playerPojo.getP_century());
        tv_p_nickname.setText(playerPojo.getP_nickname());

    }

    private void initViews(View view) {
        tv_p_id=view.findViewById(R.id.view_player_info_tv_p_id);
        tv_p_name=view.findViewById(R.id.view_player_info_tv_p_name);
        tv_p_dod=view.findViewById(R.id.view_player_info_tv_p_dod);
        tv_p_age=view.findViewById(R.id.view_player_info_tv_p_age);
        tv_p_country=view.findViewById(R.id.view_player_info_tv_p_country);
        tv_p_gender=view.findViewById(R.id.view_player_info_tv_p_gender);
        tv_p_role=view.findViewById(R.id.view_player_info_tv_p_role);
        tv_p_bat_style=view.findViewById(R.id.view_player_info_tv_p_bat_style);
        tv_p_bowl_style=view.findViewById(R.id.view_player_info_tv_p_bowl_style);
        tv_p_total_runs=view.findViewById(R.id.view_player_info_tv_p_total_runs);
        tv_p_half_century=view.findViewById(R.id.view_player_info_tv_p_half_centuries);
        tv_p_century=view.findViewById(R.id.view_player_info_tv_p_centuries);
        tv_p_nickname=view.findViewById(R.id.view_player_info_tv_p_nickname);
        getActivity().setTitle(R.string.view_player);
    }
}
